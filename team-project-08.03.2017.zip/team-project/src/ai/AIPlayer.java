package ai;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import gamegraphics.Board;
import gamegraphics.GameObject;
import gamegraphics.MathHandler;
import gamegraphics.Obstacle;
import gamegraphics.Board;
public class AIPlayer extends gamegraphics.Character {
	boolean walking;
	private Stack<String> currentMoveset;
	private Stack<String> newMoveset;
	private Node[][] fullMap;
	private boolean FirstRun;
	private ArrayList<int[]> allObstacles;
	Image character = still;
	int frames = 0;
	String bump;
	private float currentPlayerX;
	private float currentPlayerY;
	public AIPlayer(float x, float y, int width, int height, int type, float playerX, float playerY) {
		super(x, y, width, height, type);
		this.currentPlayerX = playerX;
		this.currentPlayerY = playerY;
		this.FirstRun = true;
		AStarSearch search = new AStarSearch();
		Node[][] nodeMap = search.generateNodeMap(Board.BOARDWIDTH, Board.BOARDHEIGHT);
		this.fullMap = nodeMap;
		// TODO Auto-generated constructor stub
	}
	public AIPlayer(int type) {
		super(type);
		// AI();
	}
	public void getObstacleCoordinates(Obstacle[] obstacles) {
		ArrayList<int[]> fullList = new ArrayList<int[]>();
		for (Obstacle obstacle : obstacles) {
			if (obstacle.getL()) {
				fullList.addAll(getGameObjectCoordinates(obstacle.getLeft()));
			}
			if (obstacle.getR()) {
				fullList.addAll(getGameObjectCoordinates(obstacle.getRight()));
			}
			if (obstacle.getD()) {
				fullList.addAll(getGameObjectCoordinates(obstacle.getBottom()));
			}
			if (obstacle.getU()) {
				fullList.addAll(getGameObjectCoordinates(obstacle.getTop()));
			}
		}
		// System.out.println(fullList.size());
		this.allObstacles = fullList;
		/*
		 * for (int[] obstacle : fullList){ System.out.println("X : " +
		 * obstacle[0] + " Y : " + obstacle[1]); }
		 */
		System.out.println("Obstacle size : " + this.allObstacles.size());
	}
	public ArrayList<int[]> getGameObjectCoordinates(GameObject wall) {
		ArrayList<int[]> fullCoordinates = new ArrayList<int[]>();
		float x = wall.getX();
		float y = wall.getY();
		if ((x < Board.BOARDWIDTH) && (y < Board.BOARDHEIGHT)) {
			int height = wall.getHeight();
			int width = wall.getWidth();
			for (int i = (int) x; i < ((int) x + width); i++) {
				for (int j = (int) y; j < ((int) y + height); j++) {
					int[] coord = new int[2];
					coord[0] = i;
					coord[1] = j;
					fullCoordinates.add(coord);
				}
			}
			return fullCoordinates;
		} else {
			return fullCoordinates;
		}
	}
	// TODO Auto-generated constructor stub
	public void AI(float playerX, float playerY) {
		// Behaviours
		// Need to implement behaviours
		follow(playerX, playerY);
	}
	public Node[][] setObstacles(Node[][] nodeMap) {
		int count = 0;
		while (count < this.allObstacles.size()) {
			int[] coords = allObstacles.get(count);
			if ((coords[1] < Board.BOARDHEIGHT) && (coords[0] < Board.BOARDWIDTH)) {
				nodeMap[coords[0]][coords[1]].setObstacle(true);
				nodeMap[coords[0]][coords[1]].setHeuristic(10000);
			}
			count++;
		}
		return nodeMap;
	}
	public void follow(float playerX, float playerY) {
		if (this.FirstRun == true) {
			AStarSearch newSearch = new AStarSearch();
			Node[][] nodeMap = newSearch.generateNodeMap(Board.BOARDWIDTH, Board.BOARDHEIGHT);
			//nodeMap = setObstacles(nodeMap);
			Node start = new Node((int) this.x, (int) this.y);
			Node end = new Node((int) this.currentPlayerX, (int) this.currentPlayerY);
			this.currentMoveset = newSearch.AStar(nodeMap, start, end);
			this.FirstRun = false;
		}
		if (((Math.abs(playerX - currentPlayerX) > 40) || (Math.abs(playerY - currentPlayerY) > 40))) {
			if (playerX < Board.BOARDWIDTH) {
				this.currentPlayerX = playerX;
			}
			if (playerY < Board.BOARDHEIGHT) {
				this.currentPlayerY = playerY;
			}
			AStarSearch newSearch = new AStarSearch();
			Node[][] nodeMap = newSearch.generateNodeMap(Board.BOARDWIDTH, Board.BOARDHEIGHT);
			//nodeMap = setObstacles(nodeMap);
			Node start = new Node((int) this.x, (int) this.y);
			Node end = new Node((int) this.currentPlayerX, (int) this.currentPlayerY);
			this.currentMoveset = newSearch.AStar(nodeMap, start, end);
		}
		if (this.currentMoveset.isEmpty()) {
		} else {
			String move = this.currentMoveset.pop();
			if (move.equals("up")) {
				y -= 1f;
			}
			if (move.equals("down")) {
				y += 1f;
			}
			if (move.equals("left")) {
				x -= 1f;
			}
			if (move.equals("right")) {
				x += 1f;
			}
			if (move.equals("rightup")) {
				x += 1f;
				y -= 1f;
			}
			if (move.equals("leftup")) {
				x -= 1f;
				y -= 1f;
			}
			if (move.equals("rightdown")) {
				x += 1f;
				y += 1f;
			}
			if (move.equals("leftdown")) {
				x -= 1f;
				y += 1f;
			}
		}
	}
	public Stack<String> moveSetUpdate(int aiX, int aiY) {
		final int playerX = (int) this.currentPlayerX;
		final int playerY = (int) this.currentPlayerY;
		UpdateMoveset newMoveset = new UpdateMoveset((int) playerX, (int) playerY, this.fullMap, aiX, aiY);
		Stack<String> updatedMoveset = new Stack<String>();
		// Try to make this accessible from move and cut the current movelist
		// down to 10 or some shit
		FutureTask<Stack<String>> future = new FutureTask(newMoveset);
		future.run();
		try {
			updatedMoveset = future.get();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return updatedMoveset;
	}
	public int[] futureCoordinates(int aiX, int aiY, int cullLength) {
		Stack<String> newStack = new Stack<String>();
		for (int i = 0; i < cullLength; i++) {
			newStack.push(this.currentMoveset.pop());
			String move = this.currentMoveset.pop();
			if (move.equals("up")) {
				aiY -= 1f;
			}
			if (move.equals("down")) {
				aiY += 1f;
			}
			if (move.equals("left")) {
				aiX -= 1f;
			}
			if (move.equals("right")) {
				aiX += 1f;
			}
			if (move.equals("rightup")) {
				aiX += 1f;
				aiY -= 1f;
			}
			if (move.equals("leftup")) {
				aiX -= 1f;
				aiY -= 1f;
			}
			if (move.equals("rightdown")) {
				aiX += 1f;
				aiY += 1f;
			}
			if (move.equals("leftdown")) {
				aiX -= 1f;
				aiY += 1f;
			}
		}
		Stack<String> finalStack = new Stack<String>();
		for (int j = 0; j < newStack.size(); j++) {
			finalStack.push(newStack.pop());
		}
		this.currentMoveset = finalStack;
		int[] xy = new int[2];
		xy[0] = aiX;
		xy[1] = aiY;
		return xy;
	}
	public void setBump(String bump) {
		this.bump = bump;
	}
	@Override
	public void collidedWith(GameObject other) {
		// this.sethP(gethP() - 2);
	}
	public void draw(Graphics g, GameContainer container) {
		// g.drawImage(bullet.getScaledCopy((int) (width*0.0095), (int)
		// (height*0.0095)), width/2, height/2);
		g.drawImage(character.getScaledCopy(width, height), (int) (x - width / 2), (int) (y - height / 2));
	}
}