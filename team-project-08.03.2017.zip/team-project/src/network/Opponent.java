package network;

import gamegraphics.Character;

public class Opponent extends Character {

	public Opponent(float x, float y, int width, int height, int type) {
		super(x, y, width, height, type);
		
	}
	
}
